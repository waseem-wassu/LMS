<?php

    $db=mysqli_connect("localhost","root","","liberary");  
                    /* server name, username, passwor, database name */

?>